from .funcao import validar_cadastro


def test_dados_validos_nao_geram_erros():
    erros = validar_cadastro("Maria Silva", "maria@email.com", "Senha123")
    assert erros == []


def test_nome_invalido():
    erros = validar_cadastro("Jo", "joao@email.com", "Senha123")
    assert "O nome deve ter pelo menos 3 caracteres." in erros


def test_email_invalido():
    erros = validar_cadastro("Joao", "joao-email", "Senha123")
    assert "O e-mail informado não é válido." in erros


def test_senha_invalida():
    erros = validar_cadastro("Joao", "joao@email.com", "123")
    assert "A senha deve ter pelo menos 8 caracteres." in erros


def test_varios_problemas_ao_mesmo_tempo():
    erros = validar_cadastro("Jo", "email-invalido", "123")

    assert len(erros) == 3
    assert "O nome deve ter pelo menos 3 caracteres." in erros
    assert "O e-mail informado não é válido." in erros
    assert "A senha deve ter pelo menos 8 caracteres." in erros


def test_mensagens_sao_claras():
    erros = validar_cadastro("Jo", "email-invalido", "123")

    for mensagem in erros:
        assert len(mensagem) >= 10
        assert mensagem.endswith(".")
