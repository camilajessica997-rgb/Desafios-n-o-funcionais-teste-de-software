def validar_cadastro(nome, email, senha):
    """Valida dados de cadastro e retorna todas as mensagens de erro encontradas."""
    erros = []

    if not nome or len(nome.strip()) < 3:
        erros.append("O nome deve ter pelo menos 3 caracteres.")

    if not email or "@" not in email or "." not in email.split("@")[-1]:
        erros.append("O e-mail informado não é válido.")

    if not senha or len(senha) < 8:
        erros.append("A senha deve ter pelo menos 8 caracteres.")

    return erros
