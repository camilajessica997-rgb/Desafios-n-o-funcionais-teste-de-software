def somar_numeros(n):
    """Soma todos os números inteiros de 0 até n-1."""
    return sum(range(n))
