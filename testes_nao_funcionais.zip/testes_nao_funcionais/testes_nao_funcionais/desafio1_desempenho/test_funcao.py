import time
from .funcao import somar_numeros


def test_somar_numeros_desempenho():
    entrada = 100_000

    inicio = time.perf_counter()
    resultado = somar_numeros(entrada)
    fim = time.perf_counter()

    tempo = fim - inicio
    print(f"\nTempo para {entrada:,} itens: {tempo:.6f} segundos")

    assert resultado == 4_999_950_000
    assert tempo < 1.0
