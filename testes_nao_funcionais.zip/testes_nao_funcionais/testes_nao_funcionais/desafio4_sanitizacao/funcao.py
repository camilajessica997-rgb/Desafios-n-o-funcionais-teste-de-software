import html


def sanitizar_texto(texto):
    """Converte caracteres especiais de HTML para entidades seguras."""
    return html.escape(texto, quote=True)
