from .funcao import sanitizar_texto


def test_neutraliza_script():
    texto = "<script>alert('ataque')</script>"
    resultado = sanitizar_texto(texto)

    assert "<script>" not in resultado
    assert "</script>" not in resultado
    assert "&lt;script&gt;" in resultado

    # Sem sanitização, exibir o texto como HTML poderia fazer o navegador
    # interpretar a tag script e executar JavaScript malicioso.


def test_texto_normal_continua_legivel():
    texto = "Maria Silva - estudante de Sistemas de Informação"
    resultado = sanitizar_texto(texto)

    assert resultado == texto


def test_caracteres_perigosos_sao_convertidos():
    texto = '<div class="teste">João & Maria</div>'
    resultado = sanitizar_texto(texto)

    assert "&lt;div" in resultado
    assert "&quot;teste&quot;" in resultado
    assert "&amp;" in resultado
    assert "&lt;/div&gt;" in resultado
