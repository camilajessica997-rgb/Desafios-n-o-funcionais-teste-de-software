from .funcao import Login, perfil_publico


def test_perfil_publico_nao_expoe_dados_sensiveis():
    usuario = {
        "nome": "Maria Silva",
        "email": "maria@email.com",
        "cidade": "Pontes e Lacerda",
        "senha": "SenhaSecreta123",
        "cpf": "000.000.000-00",
    }

    perfil = perfil_publico(usuario)

    assert "senha" not in perfil
    assert "cpf" not in perfil
    assert perfil["nome"] == "Maria Silva"
    assert perfil["email"] == "maria@email.com"


def test_bloqueia_apos_tres_tentativas_erradas():
    login = Login("Senha123", limite_tentativas=3)

    assert login.autenticar("errada1")[0] is False
    assert login.autenticar("errada2")[0] is False
    sucesso, mensagem = login.autenticar("errada3")

    assert sucesso is False
    assert login.bloqueado is True
    assert "bloqueada" in mensagem.lower()


def test_senha_correta_depois_do_bloqueio_e_recusada():
    login = Login("Senha123", limite_tentativas=3)

    login.autenticar("errada1")
    login.autenticar("errada2")
    login.autenticar("errada3")

    sucesso, mensagem = login.autenticar("Senha123")

    assert sucesso is False
    assert "bloqueada" in mensagem.lower()


def test_acerto_antes_do_limite_zera_contador():
    login = Login("Senha123", limite_tentativas=3)

    assert login.autenticar("errada1")[0] is False
    sucesso, _ = login.autenticar("Senha123")

    assert sucesso is True
    assert login.tentativas_erradas == 0

    # Depois de acertar, três novos erros são permitidos antes do bloqueio.
    login.autenticar("errada2")
    login.autenticar("errada3")
    sucesso, _ = login.autenticar("errada4")

    assert sucesso is False
    assert login.bloqueado is True
