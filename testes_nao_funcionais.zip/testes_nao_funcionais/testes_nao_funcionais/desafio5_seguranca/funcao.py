class Login:
    def __init__(self, senha_correta, limite_tentativas=3):
        self.senha_correta = senha_correta
        self.limite_tentativas = limite_tentativas
        self.tentativas_erradas = 0
        self.bloqueado = False

    def autenticar(self, senha):
        if self.bloqueado:
            return False, "Conta bloqueada após o limite de tentativas."

        if senha == self.senha_correta:
            self.tentativas_erradas = 0
            return True, "Login realizado com sucesso."

        self.tentativas_erradas += 1

        if self.tentativas_erradas >= self.limite_tentativas:
            self.bloqueado = True
            return False, "Conta bloqueada após o limite de tentativas."

        return False, "Senha incorreta."


def perfil_publico(usuario):
    """Retorna somente dados apropriados para exibição pública."""
    campos_publicos = ["nome", "email", "cidade"]
    return {campo: usuario[campo] for campo in campos_publicos if campo in usuario}
