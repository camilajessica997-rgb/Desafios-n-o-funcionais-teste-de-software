# Lista de Desafios: Testes Não Funcionais

**Disciplina:** Teste de Software  
**Framework:** pytest  
**Linguagem:** Python

## Objetivo

Este trabalho implementa cinco desafios de testes não funcionais envolvendo desempenho, usabilidade e segurança.

## Estrutura

```text
testes_nao_funcionais/
├── desafio1_desempenho/
│   ├── funcao.py
│   └── test_funcao.py
├── desafio2_comparacao/
│   ├── funcao.py
│   └── test_funcao.py
├── desafio3_usabilidade/
│   ├── funcao.py
│   └── test_funcao.py
├── desafio4_sanitizacao/
│   ├── funcao.py
│   └── test_funcao.py
├── desafio5_seguranca/
│   ├── funcao.py
│   └── test_funcao.py
└── README.md
```

## Desafio 1 — Orçamento de tempo

A função soma 100 mil números e o teste mede o tempo com `time.perf_counter()`. O teste verifica o resultado e utiliza um limite de 1 segundo. O tempo é impresso no terminal.

## Desafio 2 — Comparando duas implementações

Foram criadas duas formas de procurar um item: uma busca ingênua, percorrendo a lista, e uma busca eficiente utilizando `set`. O teste verifica que as duas retornam o mesmo resultado e compara os tempos.

## Desafio 3 — Mensagens claras ao usuário

A função valida nome, e-mail e senha. Em vez de parar no primeiro problema, ela retorna todas as mensagens encontradas. Os testes verificam dados válidos, erros individuais, múltiplos erros e clareza das mensagens.

## Desafio 4 — Sanitização de entrada

A função utiliza `html.escape()` para transformar caracteres especiais de HTML em entidades seguras. O teste verifica uma tentativa com `<script>` e também garante que texto comum continue legível.

Sem sanitização, um conteúdo malicioso inserido em uma página HTML poderia ser interpretado pelo navegador como código.

## Desafio 5 — Proteção de dados e de acesso

### Parte A — Dados sensíveis

A função `perfil_publico()` retorna somente os campos destinados à exposição pública. Senha e CPF não aparecem no resultado.

### Parte B — Tentativas de acesso

A classe `Login` bloqueia a conta depois de três tentativas erradas. Uma senha correta antes do limite zera o contador. Depois que a conta é bloqueada, até a senha correta é recusada.

## Como executar

Abra o terminal dentro da pasta `testes_nao_funcionais` e execute:

```bash
python -m pytest -v
```

Para visualizar também os tempos impressos:

```bash
python -m pytest -v -s
```

## Resultado esperado

Todos os testes devem passar. Os tempos apresentados pelo Desafio 1 e pelo Desafio 2 podem variar de acordo com o computador utilizado.
