def buscar_ingenua(dados, alvo):
    """
    Procura um elemento percorrendo a lista do início ao fim.
    """
    for item in dados:
        if item == alvo:
            return True

    return False


def preparar_indice(dados):
    """
    Cria um Set para permitir buscas mais rápidas.
    """
    return set(dados)


def buscar_eficiente(indice, alvo):
    """
    Procura um elemento usando um Set.
    """
    return alvo in indice