import time

from .funcao import (
    buscar_ingenua,
    preparar_indice,
    buscar_eficiente
)


def test_resultados_iguais():
    dados = list(range(100_000))
    indice = preparar_indice(dados)

    alvo = 99_999

    resultado_lento = buscar_ingenua(dados, alvo)
    resultado_rapido = buscar_eficiente(indice, alvo)

    assert resultado_lento == resultado_rapido


def test_desempenho():
    dados = list(range(100_000))

    # O índice é criado antes da medição.
    # Assim, estamos comparando somente as buscas.
    indice = preparar_indice(dados)

    # Várias buscas tornam a diferença de desempenho mais evidente.
    alvos = list(range(99_000, 100_000))

    inicio = time.perf_counter()

    for alvo in alvos:
        buscar_ingenua(dados, alvo)

    tempo_lenta = time.perf_counter() - inicio

    inicio = time.perf_counter()

    for alvo in alvos:
        buscar_eficiente(indice, alvo)

    tempo_rapida = time.perf_counter() - inicio

    print(f"\nBusca ingênua:    {tempo_lenta:.6f} segundos")
    print(f"Busca eficiente:  {tempo_rapida:.6f} segundos")

    assert tempo_rapida <= tempo_lenta